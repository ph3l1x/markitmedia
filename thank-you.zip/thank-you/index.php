<?php
//get vars
$page = 0;
$title = 'Thank You';
$description = 'Markit Media is a professional Web Design, Print, Graphics, Marketing, SEO, studio in Scottsdale Arizona.';
$keywords = 'Scottsdale Web Design, Scottsdale Print, Scottsdale Graphic Design, SEO Scottsdale, Marketing Scottsdale, Php Programming Scottsdale';
$bottomDescription = "<p>Markit Media is a one stop shop for all your Web, Graphic, Print and Marketing needs. We are a full service web design company in the United States. We are located here in the valley in Scottsdale Arizona. We offer informational and E-Commerce web sites with HTML and Flash designs. Markit Media can help promote your small business online. We build professional, custom designed, websites. We have packages for new business that include logo and brand identity, 1000 business cards, 1000 tri-fold brochures, custom designed letterhead, and 5 page informative style website.</p>
                	  <p>Markit Media, Scottsdale Web Design, Scottsdale Marketing, Scottsdale Web Developer, Scottsdale Print, Scottsdale Printing, Scottsdale Graphic Design, Professional Marketing Scottsdale AZ, Professional Marketing Phoenix AZ, Professional Marketing Arizona, Professional Web design Scottsdale Arizona, Professional Web Design Phoenix Arizona, Professional Web Design Arizona, Professional Printing Scottsdale Arizona, Professional Printing Phoenix Arizona, Professional Printing Arizona, Professional Business Cards Scottsdale Arizona, Professional Business Cards Phoenix Arizona, Professional Business Cards Arizona.</p>";

$thankyou = true;

require_once('../header.php');
?>
<!-- Google Code for Lead Gen Form Conversion Page -->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 939686428;
var google_conversion_language = "en";
var google_conversion_format = "3";
var google_conversion_color = "ffffff";
var google_conversion_label = "4r8CCJuBi2EQnPSJwAM";
var google_remarketing_only = false;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/939686428/?label=4r8CCJuBi2EQnPSJwAM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>
<div class="wrapper">
	<div class="pageContent thankYou">
    	<h1>We will be in contact with you shortly.</h1>
    </div>
</div>
<div id="content">
	<div id="contentTop"></div>
    <div id="contentBody">
    	<div class="wrapper">
        	<div class="welcome">
            </div>
            
            <div id="thankyou" style="width:600px;display: none;">
                <h3>Welcome!</h3>
                <p id="one">Our web marketing and printing experts will be in touch with you within 24 hours.</p>
                <p id="two"><strong>Thank you</strong> for contacting us. We're excited for you to join other businesses who have stopped worrying about their website, marketing, graphics, and printing. We'll take it from here.</p>
            </div>
        	
<!-- Google Code for Lead Gen Form Conversion Page --> <script
type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 939686428;
var google_conversion_language = "en";
var google_conversion_format = "3";
var google_conversion_color = "ffffff";
var google_conversion_label = "4r8CCJuBi2EQnPSJwAM"; var
google_remarketing_only = false;
/* ]]> */
</script>
<script type="text/javascript"  
src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt=""  
src="//www.googleadservices.com/pagead/conversion/939686428/?label=4r8CCJuBi
2EQnPSJwAM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>
<?php
require_once('../footer.php');
?>